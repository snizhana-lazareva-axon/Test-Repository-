# Test Cases - Template and Rules

> [!IMPORTANT]
> You MUST use strict **HTML Tables** for test cases, NOT Markdown tables.
> This is mandatory for Confluence integration. If you output a Markdown table, you have failed.
>
> **CRITICAL - HTML table integrity rules (violations break Confluence preview):**
> 1. NO HTML comments (`<!-- ... -->`) anywhere inside `<table>`, `<thead>`, `<tbody>`, or `<tr>` tags.
> 2. NO blank lines between `</tr>` and `<tr>` inside `<tbody>`.
> 3. NO blank line between `</tbody>` and `</table>`.
> 4. HTML comments are allowed OUTSIDE table tags but must never appear inside any table element.
> 5. For text formatting (bold/italic) inside table cells, use Markdown syntax (`**bold**`, `*italic*`). Only exception: `<u>` for underline.
> 6. These pages also render in the Docusaurus Knowledge Centre (the `workspace/sprints` docs source) through an MDX theme. Obey the **Docusaurus / MDX readiness** rules below or the KC build breaks even when Confluence renders fine.

## Docusaurus / MDX readiness

Test-case pages under `workspace/sprints/` are compiled as MDX by Docusaurus and rendered by the custom theme in `src/theme/DocItem/Content/index.js`. MDX parses cell content as JSX, so it is stricter than Confluence. A freshly authored page MUST satisfy all of the following or it will fail to render:

1. **Column widths use the JSX object form, never a string.** Write `<col style="width: 228px;" />`. A string attribute (`style="width: 228px;"`) throws at render time (React: "the `style` prop expects a mapping, not a string"). This applies to every `<col>` and any inline `style`.
2. **Escape or fence curly braces in cell text.** A bare `{` or `}` anywhere in a cell (JSON payloads, code snippets, error blobs like `"errors": [...]`, object samples) is parsed as a JS expression and breaks the build. Wrap any such content in inline code (`` `{...}` ``) or a `<code>...</code>` element — braces inside code spans are safe and render literally.
3. **Escape or fence literal `<` and `>` in prose.** MDX reads `<` as the start of a tag. Write comparisons as `->` / `&lt;` / `&gt;`, or put the text inside inline code (e.g. `` `value < 100` ``). Do not write a bare `2 < 3` or `<value>` in cell prose.
4. **Self-close void elements.** Use `<br />` and `<col ... />` (with the trailing slash). Bare `<br>` is invalid JSX and fails the build.
5. **Markdown inside cells still renders.** `**bold**`, `*italic*`, backtick code, and `[label](url)` links work inside `<td>`/`<th>`. Prefer `**[TC-NN] Title**` over a literal `<strong>` tag for case titles — the theme styles the rendered `<strong>`, so both work, but keep one convention.
6. **Keep the attribute the theme keys on.** The main cases table must carry `data-number-column="true"` (the theme injects the row-number column and status/type styling from it). Every table uses `data-layout="default"` with per-column widths in the `<colgroup>` only - do not set `data-table-width` and do not use `data-layout="center"`.

If a value genuinely needs braces or angle brackets shown to the reader, always fence it. When in doubt, fence it.

## File naming

Use the same "type first" rule as BA documents.

- Canonical file name: `test-cases-<primary-key>-<slug>.md`
- Example: `test-cases-PROJ-11311-department-registry.md`
- Place it in the sprint scope folder when one exists, for example:
  - `workspace/sprints/sprint-1.68.0/proj-11308/test-cases-PROJ-11311-department-registry.md`
  - `workspace/sprints/sprint-1.68.0/stage-retest-1.68.0/test-cases-PROJ-11311-department-registry.md`

Rules:

- `test-cases` stays at the beginning of the file name
- `primary-key` is the main Jira identity anchor in the filename
- `<slug>` is lowercase kebab-case and should match the page summary/theme
- Legacy names like `tests-proj-11311-...` are old style; do not use them for new files

## File Structure

Every test case file uses YAML frontmatter for document metadata and `## Body` for HTML table content.

```markdown
---
type: test-cases
primary-key: PROJ-XXXX
covers:
- PROJ-XXXX
issues:
- PROJ-NNNNN
title: "PROJ-XXXX: Feature Name - Test Cases"
hide_table_of_contents: true
space-id: "<Confluence space ID>"
parent-id:
version: 1
environment: "[Staging](https://sandbox.example.com/)"
# Optional dashboard fields. Omit when unknown.
# sprint: "Sprint-1.68.0"
# fix-version: "v1.68.0"
# feature-id: "feature:tenant-improvement-plan"
# story-ids:
# - "story:tenant-improvement-plan:us-1"
status-summary:
  planned: 0
  passed: 0
  failed: 0
  blocked: 0
  skipped: 0
# confluence-url: "https://example.atlassian.net/wiki/spaces/PROJ/pages/123456789/Page+Title"
---

## Body

[HTML tables here - see structure below]
```

## Frontmatter Fields

| Field | Required | Description |
| --- | --- | --- |
| `type` | Yes | Document type. Always `test-cases`. Used by KC to select the test case layout. |
| `primary-key` | Yes | Canonical Jira key for file identity, naming, and main scope anchor |
| `covers` | Yes | Array of Jira issue keys directly covered by the test cases |
| `issues` | No | Array of related bugs, regressions, sibling tasks, or watchlist keys |
| `title` | Yes | Confluence page title. Format: `PROJ-XXXX: Summary - Test Cases` |
| `hide_table_of_contents` | Yes | Docusaurus flag. Always `true` for test-case pages — the body is HTML tables under one `## Body`, so the right-side outline is empty noise. |
| `space-id` | Yes | Confluence space ID. Use the target project's configured value |
| `parent-id` | Yes | Confluence parent page ID. Resolve from sprint config or ask user. NEVER guess. |
| `version` | Yes | Confluence page version. Starts at `1`. Increment on each update. |
| `environment` | Yes | Environment link(s) used for execution. See "Environment Rules" below - never guess, never mix a Sandbox label with a prod/stage URL |
| `sprint` | No | Sprint folder/name, e.g. `Sprint-1.68.0` |
| `fix-version` | No | Release version, e.g. `v1.68.0` |
| `feature-id` | No | Knowledge Centre feature slug. Example: `feature:tenant-improvement-plan` |
| `story-ids` | No | Story anchors used by dashboard traceability |
| `status-summary` | Generated | Rollup derived from the Status column. Agents/scripts may update it. Humans do not hand-maintain it. |
| `confluence-url` | No | Full Confluence URL, filled after first successful publish |

## Environment Rules

Two test environments are defined. Do not blend their labels and URLs.

| Environment | Domain | Use for |
| --- | --- | --- |
| Sandbox | `https://sandbox.example.com/` (subdomain per test org, e.g. `https://sandbox.example.com/`) | New feature coverage - first test pass on work not yet verified/released |
| Stage | `https://stage.example.com/` | Re-test and regression - verifying a fix or release candidate ahead of prod |

Rules:
- The link **label** and the link **domain** must refer to the same environment. `[Staging](https://malling.fazile.no/)` is wrong on both counts - `malling.fazile.no` is a production customer domain, not Stage, and the label does not match it either.
- Production domains (`*.fazile.no` customer instances) are for bug repro reference only - they belong in a bug draft's `environment` field when the defect was observed live, never as the `environment` in a test-cases doc used to plan or execute tests.
- If the actual environment is unknown, leave `environment` unset in frontmatter (omit the key) and use plain text `TBD - confirm environment` in the body Environment row. Never fabricate a plausible-looking link.

## Case Types

Use one or more of these values in the **Type** column. Keep it boring. Boring is searchable.

| Type | Use when |
| --- | --- |
| `Positive` | Happy path or primary business flow |
| `Negative` | Invalid input, forbidden action, rejected state |
| `Boundary` | Min/max, empty, zero, date edge, rounding edge |
| `Access` | Role, permission, visibility, tenant/property access |
| `Integration` | API, Jira/ERP/Visma, callback, cross-service behavior |
| `Calculation` | VAT, rent, discount, invoice, settlement, rounding |
| `Regression` | Known defect, previously broken flow, bug retest |
| `Data` | Migration, import/export, existing record compatibility |

Rules:
- Prefer one primary type. Use comma-separated values only when useful, e.g. `Calculation, Boundary`.
- Do not invent type names. New types need a template update first.
- Validation fields belong in one consolidated test case, not twenty tiny test confetti rows.

## Statuses

Use only these values in the **Status** column:

| Status | Meaning | Bug / Note rule |
| --- | --- | --- |
| `Planned` | Test exists but has not been executed | Optional short setup or clarification note |
| `Passed` | Executed and matched expected results | Empty after execution cleanup |
| `Failed` | Executed and did not match expected results | Bug key required when bug exists; otherwise short failure note |
| `Blocked` | Cannot execute because data, environment, access, or dependency is missing | Blocking reason required |
| `Skipped` | Intentionally not executed for this run | Reason required |

Rules:
- New AI-generated drafts start as `Planned`.
- Treat **Bug / Note** as temporary execution workspace, not an evidence log. While testing, keep only the current fact needed to understand the row.
- After a test passes, clear **Bug / Note**. Detailed commands, payloads, IDs, timestamps, calculations, and retest history belong in the separate evidence artifact or bug report.
- After a bug is published, replace the failure narrative with only the linked Jira bug key, for example `[PROJ-12345](https://example.atlassian.net/browse/PROJ-12345)`. The bug report owns the evidence.
- After a bug is fixed and the row passes retest, clear **Bug / Note**; keep `Bug: PROJ-12345` in **Traceability** when regression linkage remains useful.
- `Blocked` and `Skipped` keep one short current reason only. Replace stale reasons; never append a chronology.
- Do not use `[!INFO]` panels in **Expected Results** for status coloring. Status lives in the **Status** column now. Yes, civilization advances.
- `status-summary` in frontmatter is derived from the Status column. Agents/scripts may refresh it before dashboard publishing. Humans do not manually maintain planned/passed/failed/blocked/skipped counts.
- To refresh it, run `python3 .agents/scripts/update_test_status_summary.py <test-file.md>`.
- If `status-summary` is absent or stale, the dashboard must compute counts from the table rows.

## Traceability Rules

The **Traceability** column is the dashboard contract. It links tests to stories, AC, rules, and bugs.

Allowed line format:

```text
Story: PROJ-XXXX or story:<feature-slug>:<story-id>
AC: AC1, AC2
Rule: <short business rule name>
Bug: PROJ-NNNNN
```

Rules:
- Every row needs at least `Story:` or a direct Jira key from `covers`.
- Use `AC:` when the source story has acceptance criteria. If the case is exploratory/regression only, use `AC: N/A - regression` or `AC: N/A - exploratory`.
- Use `Rule:` for calculation/entity/business-rule coverage that is not cleanly captured by AC.
- Use `Bug:` only for regression tests or failed executions tied to an existing bug.
- Do not invent story anchors. If no story anchor exists yet, use the Jira key and add a note in **Bug / Note**.

## Preconditions

Story/Task, Issues, and Environment already live in frontmatter (`primary-key`/`covers`, `issues`, `environment`) - do not repeat them in the body as a metadata table. Preconditions is the only shared-setup content the body needs, and it is a plain paragraph + list, not a table - there is nothing tabular about a list of setup requirements.

```markdown
## Body

### Preconditions

- [Combined preconditions as bullet points]
- [Example: user is logged in as Admin]
- [Example: two orgs exist with the setup described above]
```

Rules:
- Keep it short. If a precondition is specific to one case, put it in that case's steps instead of here.
- Do not resurrect the old three-row metadata table (Story/Task, Issues, Environment) - that data is already in frontmatter and duplicating it drifts out of sync.

## HTML Table Structure

```html
<table data-layout="default" data-number-column="true">
    <colgroup>
        <col style="width: 275px;" />
        <col style="width: 115px;" />
        <col style="width: 150px;" />
        <col style="width: 380px;" />
        <col style="width: 100px;" />
        <col style="width: 230px;" />
    </colgroup>
    <thead>
        <tr>
            <th>**Case**</th>
            <th>**Type**</th>
            <th>**Traceability**</th>
            <th>**Expected Results**</th>
            <th>**Status**</th>
            <th>**Bug / Note**</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
                **[TC-01] [Test case title]**
                <ol>
                    <li>Navigate to [Page]</li>
                    <li>Click [Action]</li>
                    <li>Enter [Value]</li>
                </ol>
            </td>
            <td>Positive</td>
            <td>
                Story: PROJ-XXXX<br />
                AC: AC1<br />
                Rule: [Rule name]
            </td>
            <td>
                <ol>
                    <li>[Expected outcome 1]</li>
                    <li>[Expected outcome 2]</li>
                </ol>
            </td>
            <td>Planned</td>
            <td></td>
        </tr>
        <tr>
            <td>
                **[TC-02] [Regression title]**
                <ol>
                    <li>...</li>
                </ol>
            </td>
            <td>Regression</td>
            <td>
                Story: PROJ-XXXX<br />
                AC: N/A - regression<br />
                Bug: PROJ-NNNNN
            </td>
            <td>
                <ol>
                    <li>...</li>
                </ol>
            </td>
            <td>Planned</td>
            <td>Regression coverage for PROJ-NNNNN</td>
        </tr>
    </tbody>
</table>
```

## Composition Rules

- One row = one business scenario, not one click.
- Case cell contains a short title plus steps.
- Expected Results cell contains only expected observable behavior. No status panels.
- Keep manual tests executable in 3-7 steps when possible.
- Put shared setup in the `### Preconditions` list. If the same setup appears in 3 or more cases, it does not belong in each row.
- Use exact UI labels, endpoint names, entity names, and calculation outputs when known.
- If the expected result depends on a calculation, include the concrete input and expected number.
- If the requirement is unclear, write the ambiguity in **Bug / Note** and keep Status as `Planned` until reviewed.
- Before sign-off or publication, run a **Bug / Note cleanup pass** across every row using the lifecycle rules above.

## Publishing

The `confluence-publisher` skill reads frontmatter for all publication metadata:
- `space-id` -> `spaceId`
- `parent-id` -> `parentId`
- `title` -> page title
- `version` -> current version (increment by 1 on update)
- `confluence-url` -> written back after successful publish

After a successful publish, write the returned page URL back into `confluence-url` and increment `version` by 1.

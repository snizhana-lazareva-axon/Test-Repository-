# Bug Report – Template and Rules

> [!IMPORTANT]
> Do not deviate from the specified structure or formatting.

## Bug Rules
1. Steps must be reproducible without hidden context.
2. Expected result must state an exact observable output, not "works correctly" or similar fluff.
3. If the bug is about a calculation, percentage, ratio, threshold, rounding rule, or derived value, include at least one worked example with concrete inputs and the expected output.

## File structure

Bug report drafts use YAML frontmatter for Jira field values, including `environment`, and `## Description` for the Jira description payload.

## File naming

Use the same "type first" rule as BA documents.

- Draft bug file: `bug-<N>-<slug>.md`
- After Jira create: `bug-<N>-PROJ-NNNNN-<slug>.md`
- Example draft: `bug-1-contract-status-change-500-leading-zero-personal-id.md`
- Example post-sync: `bug-1-PROJ-11368-contract-status-change-500-leading-zero-personal-id.md`

Rules:

- Keep `bug` at the beginning of the filename
- Keep the stable draft order number `<N>` if several bug drafts exist in the same scope
- Insert the Jira key after sync; do not replace the type prefix with the Jira key
- `<slug>` stays lowercase kebab-case
- Legacy names like `proj-11179-bug.md` or slug-only bug files are old style; do not use them for new files

	```markdown
	---
	type: Bug
	key:
	summary: "[Prefix]. [concise summary]"
	priority: "[Priority]"
	severity: "[Severity]"
	root-cause: "[Root cause]"
	environment: "[Environment](https://sandbox.example.com/...)"
	# Optional fields (omit keys entirely if unknown; never use empty strings):
	# sprint: "[Sprint]"
	# fix-version: "[Fix version]"
	# assignee: "[Assignee]"
	# components: ["[Component]"]
	labels: [impact-ui, release-notes]
	# linked-issues: ["relates to: PROJ-NNNNN"]
	# Test coverage traceability. Fill when the bug came from a test case.
	# source-test-doc: "workspace/sprints/sprint-X.YY.Z/<scope>/test-cases-PROJ-XXXX-<slug>.md"
	# source-test-cases:
	# - "TC-01"
	# feature-id: "feature:tenant-improvement-plan"
	# story-ids:
	# - "story:tenant-improvement-plan:us-1"
	# acceptance-criteria:
	# - "AC1"
	# Optional scheduling fields (ONLY if user provides values; otherwise omit keys entirely):
	# start-date: "YYYY-MM-DD"
	# target-end: "YYYY-MM-DD"
	# original-estimate: "2h" # or "1d 4h"
	---

## Description

**Steps**
1. [Step 1]
2. [Step 2]

**Actual result**

[What actually happened]

**Expected result**

[What should happen]

**Worked example** (required when the bug is about calculation logic)

[Concrete input values and expected output]

## User Interaction and Release Impact

**Impact summary:** [One-sentence description or "Internal only - reason"]

**Affected audience:** [Concrete user roles, customer administrators, API consumers, Product Owner, or internal teams]

**Behavior before:** [Current behavior]

**Behavior after:** [Expected behavior after the fix]

**Customer action required:** [No - reason / Yes - action; Owner: Jira mention or role; Deadline: date or release condition]

**Product Owner communication:** [Pending / Approved / Not required - reason; Owner: Jira mention or role; Planned date: date or release condition]

**External communication:** [No - reason / Yes - Audience: group; Channel: method; Owner: Jira mention or role; Timing: date or release condition]

**Compatibility or migration:** [No impact - reason / exact compatibility, configuration, or migration requirement]

**Stage verification:** [Scenario and exact expected evidence]

<!-- LOCAL ONLY - do not push to Jira. Any `## Sub-tasks` section below is a local search index only. -->
## User Impact Readiness
- [ ] Controlled labels comply with `.agents/rules/user-impact-and-release-labels.md`?
- [ ] Product Owner communication and customer action decision recorded; every named Jira user uses `[@Display Name](mention://accountId)`?
- [ ] Stage verification names exact evidence?

```

### Frontmatter fields

| Field | REQ/OPT | Jira mapping | Notes |
| --- | --- | --- | --- |
| `type` | REQ | `issuetype` | Always `Bug` |
| `key` | — | — | Empty on draft; filled after Jira create |
| `summary` | REQ | `summary` | Prefix `Web.` or `Server.` |
| `priority` | OPT | `priority` | Highest / High / Medium / Low / Trivial |
| `severity` | REQ | `customfield_10939` | Blocker / Critical / Major / Trivial |
| `root-cause` | REQ | `customfield_11066` | See categories below |
| `sprint` | OPT | `customfield_10006` | Sprint name; resolve to numeric ID via `get_jira_board_sprints` |
| `fix-version` | OPT | `fixVersions` | Target release, e.g. `v1.66.0` |
| `assignee` | OPT | `assignee` | Display name; resolve to `accountId` via `search_jira_assignees` |
| `components` | OPT | `components` | YAML list of component names |
| `labels` | REQ | `labels` | Include at least one controlled `impact-*` label; see `.agents/rules/user-impact-and-release-labels.md` |
| `linked-issues` | OPT | `linkedIssues` | YAML list, e.g. `["relates to: PROJ-XXXX"]` |
| `source-test-doc` | OPT | Local/dashboard only | Relative path to the test case document that exposed the bug |
| `source-test-cases` | OPT | Local/dashboard only | Test case IDs from the Case column, e.g. `TC-01` |
| `feature-id` | OPT | Local/dashboard only | Knowledge Centre feature slug, e.g. `feature:tenant-improvement-plan` |
| `story-ids` | OPT | Local/dashboard only | Story anchors used by dashboard traceability |
| `acceptance-criteria` | OPT | Local/dashboard only | AC IDs linked to the failed or blocked test |
| `start-date` | OPT | `startDate` | YYYY-MM-DD. Omit the key if unknown. Never set `""`. |
| `target-end` | OPT | `duedate` | YYYY-MM-DD. Omit the key if unknown. Never set `""`. |
| `original-estimate` | OPT | `timetracking.originalEstimate` | e.g. `2h`, `1d 4h`. Omit the key if unknown. Never set `""`. |

### Bug Traceability Rules

Use traceability fields when a bug is found during test execution:

1. If the bug comes from a planned test, set `source-test-doc` and `source-test-cases`.
2. If the failed test maps to story/AC coverage, set `feature-id`, `story-ids`, and `acceptance-criteria` when known.
3. Add a matching entry in the test row:
   - **Status** = `Failed` or `Blocked`
   - **Bug / Note** = Jira bug key after creation, or short blocker/failure note while draft is not yet published
4. Keep Jira relationship in `linked-issues`, e.g. `["relates to: PROJ-XXXX"]`.
5. Do not invent feature/story/AC IDs. Omit unknown fields and leave a short note in the test row. Yes, omission beats fiction. Barely.

### Body sections

Only one section goes in the body. Everything else is frontmatter.

| Section | Jira destination | Strip heading? |
| --- | --- | --- |
| `## Description` content (Steps, Actual, Expected, User Interaction and Release Impact) | `description` field | Yes – strip the `## Description` heading itself |

`environment` is ADF-capable through the Jira API. It lives in frontmatter and must contain only environment link(s), authored as Markdown links or bare URLs. Do not put credentials, labels, request IDs, notes, screenshots, or reproduction details there.

## Root cause categories

Pick the single best-fit. QA initial assessment – team reviews and adjusts.

| Category | Apply when |
| --- | --- |
| Implementation | Incorrect logic, missing condition, wrong data handling in code. Most common. |
| Infrastructure/Deployment | Environment mismatch, deployment error, config issue. |
| Regression | Bug reintroduced as side-effect of another feature or fix. |
| Incomplete/Ambiguous requirements | AC was unclear, missing, or contradictory. Use sparingly. |
| Third-party/Dependency | External API, library, or tool not functioning as expected. |
| Corner case | Rare or unexpected data/user behavior not initially considered. |

> "Design Gap" and "Requirement Gap" issues are usually Improvements, not bugs. Use Incomplete/Ambiguous requirements only when a bug directly stems from missing AC.

## Assignee resolution (bug-specific)

If `assignee` is not explicitly provided:
1. Identify the related Jira issue key (from `linked-issues` or user context).
2. Call `get_jira_issue [relatedKey]` and examine its subtasks.
3. Match by prefix: `Web.` -> subtask with "Web/Frontend/UI"; `Server.` -> "Server/Backend/API".
4. Call `search_jira_assignees` with that subtask's assignee name to get `accountId`.
5. If no matching subtask: use the parent task's assignee.

## Publishing to Jira

The `qa-engineer` skill reads frontmatter for Jira field values. The `## Description` body section supplies the Jira `description` payload. The frontmatter `environment` key supplies the Jira `environment` payload and must contain only environment link(s).

After successful create: write the returned issue key into `key` in the frontmatter and rename the local file heading.

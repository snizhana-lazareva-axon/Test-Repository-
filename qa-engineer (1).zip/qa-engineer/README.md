# QA Skill - PM-QA Guide

This directory is the complete package to share with a PM-QA employee. Its
`SKILL.md` contains the full QA Engineer v2.1 logic from the repository skill;
only the template references were changed to use bundled files. Share the whole
`qa-engineer` directory. Sending only `SKILL.md` drops the templates, which would
be a very efficient way to make the skill less useful.

## Package structure

```text
qa-engineer/
  README.md
  SKILL.md
  assets/
    test-cases-template.md
    bug-report-template.md
```

- `SKILL.md` contains QA coverage and bug-writing instructions.
- `assets/test-cases-template.md` is the full canonical test-case template.
- `assets/bug-report-template.md` is the full canonical bug-report template.

## Project repository structure

```text
workspace/
  sprints/
    README.md
    sprint-X.YY.Z/
      README.md
      proj-NNNNN/
        test-cases-PROJ-NNNNN-<slug>.md
        bug-1-<slug>.md
        bug-1-PROJ-NNNNN-<slug>.md
tmp/
```

Use the Jira key of the tested Story, Improvement, or Task for the folder name.

Example:

```text
workspace/sprints/sprint-1.69.0/project-11234/
  test-cases-PROJ-11234-contract-create.md
  bug-1-PROJ-11901-invalid-area-id-is-accepted.md
```

## Where each file belongs

- Test cases:
  `workspace/sprints/sprint-X.YY.Z/proj-NNNNN/test-cases-PROJ-NNNNN-<slug>.md`
- Bug found during those tests: beside the owning test-case document.
- Bug before Jira creation: `bug-<N>-<slug>.md`.
- Bug after Jira assigns a key: `bug-<N>-PROJ-NNNNN-<slug>.md`.
- Temporary screenshots, request dumps, and response dumps: repository `tmp/`.
  Do not commit them unless the team deliberately promotes them into a safe
  permanent artifact.

## Locations that are read-only for QA authors

- `.agents/context/jira-tasks/` and `.agents/context/jira-bugs/` are Jira cache and
  reference material. Do not create or edit QA artifacts there.
- `workspace/features/` contains requirements and design artifacts, not sprint
  execution results.
- `docs/` contains published product and technical documentation.
- `.agents/skills/` contains the repository's operational skills, not test output.

## PM-QA workflow

1. Find the sprint and owning Jira issue.
2. Read the full requirement and Acceptance Criteria.
3. Create or reuse the issue folder under the sprint.
4. Draft the test file from `assets/test-cases-template.md`.
5. Link every test to its Jira issue and Acceptance Criterion.
6. Execute tests and update Status. Keep only the current failure or blocking fact
   in `Bug / Note`.
7. Draft a reproduced bug beside the test file using
   `assets/bug-report-template.md`.
8. After Jira creates the bug, add the Jira key, rename the bug file, and replace
   the failed test row's narrative with only the Jira key.
9. After successful retest, mark the row Passed and clear `Bug / Note`.

## Non-negotiable file rules

- Test file: `test-cases-PROJ-NNNNN-<slug>.md`.
- Test tables: strict HTML, never Markdown tables.
- One test document has one `primary-key`; `covers` lists every directly tested
  Jira issue.
- Bug reproduction uses a fresh equivalent setup. Old IDs are evidence, not setup
  instructions.
- API write tests cover invalid and contradictory IDs and verify no partial
  persistence.
- Never store API tokens, passwords, cookies, or authorization headers in the
  repository.

## Sharing and installation

Copy this complete directory into the recipient's Codex skills directory, keeping
the folder name `qa-engineer`, or send it as a folder for use alongside the project
repository. The package does not depend on files from the sender's private skill
directory.
